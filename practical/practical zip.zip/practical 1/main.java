
package waypoint.model;

import java.util.ArrayList;
import java.util.Currency;
import java.util.List;
import java.math.BigDecimal;

public final class Money implements Comparable<Money> {

    private final long paise;
    private final Currency currency;

    private Money(long paise, Currency currency) {
        if (currency == null) {
            throw new IllegalArgumentException("Currency cannot be null");
        }
        this.paise = paise;
        this.currency = currency;
    }

    public static Money ofMinor(long paise, Currency currency) {
        return new Money(paise, currency);
    }

    public static Money rupees(long rupees) {
        return new Money(Math.multiplyExact(rupees, 100L),
                Currency.getInstance("INR"));
    }

    public long getPaise() {
        return paise;
    }

    public Currency getCurrency() {
        return currency;
    }

    private void checkCurrency(Money other) {
        if (other == null || !currency.equals(other.currency)) {
            throw new IllegalArgumentException("Currency mismatch");
        }
    }

    public Money plus(Money other) {
        checkCurrency(other);
        return new Money(Math.addExact(paise, other.paise), currency);
    }

    public Money minus(Money other) {
        checkCurrency(other);
        return new Money(Math.subtractExact(paise, other.paise), currency);
    }

    public Money times(int multiplier) {
        return new Money(Math.multiplyExact(paise, multiplier), currency);
    }

    public boolean isNegative() {
        return paise < 0;
    }

    @Override
    public int compareTo(Money other) {
        checkCurrency(other);
        return Long.compare(paise, other.paise);
    }

    public List<Money> allocate(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("Number of shares must be positive");
        }

        List<Money> shares = new ArrayList<>();

        long quotient = paise / n;
        long remainder = paise % n;

        for (int i = 0; i < n; i++) {
            long share = quotient;

            if (i < Math.abs(remainder)) {
                share += Long.signum(remainder);
            }

            shares.add(new Money(share, currency));
        }

        return List.copyOf(shares);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof Money)) {
            return false;
        }

        Money other = (Money) obj;

        return paise == other.paise &&
                currency.equals(other.currency);
    }

    @Override
    public int hashCode() {
        return 31 * Long.hashCode(paise) + currency.hashCode();
    }

    @Override
    public String toString() {
        return currency.getCurrencyCode() + " " +
                BigDecimal.valueOf(paise, 2).toPlainString();
    }
}
