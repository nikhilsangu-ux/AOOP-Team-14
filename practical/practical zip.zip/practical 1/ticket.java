
package waypoint.model;

import java.time.Instant;
import java.util.Objects;

/**
 * ENTITY. Invariants:
 * I1 entry is always present
 * I2 exit is null, or not before entry
 * I3 fare is null, or not negative
 * I4 fare exists only if exit exists
 * I5 a closed ticket never reopens
 */
public final class Ticket {

    private final TicketId id;
    private final SpotId spotId;
    private final Instant entry;

    private Instant exit;
    private Money fare;

    private Ticket(TicketId id, SpotId spotId, Instant entry) {
        this.id = Objects.requireNonNull(id, "TicketId cannot be null");
        this.spotId = Objects.requireNonNull(spotId, "SpotId cannot be null");
        this.entry = Objects.requireNonNull(entry, "Entry time cannot be null");
    }

    public static Ticket open(TicketId id, SpotId spotId, Instant entry) {
        return new Ticket(id, spotId, entry);
    }

    public boolean isOpen() {
        return exit == null;
    }

    public Money close(Instant at, FarePolicy policy) {

        Objects.requireNonNull(at, "Exit time cannot be null");
        Objects.requireNonNull(policy, "FarePolicy cannot be null");

        if (!isOpen()) {
            throw new TicketAlreadyClosed();
        }

        if (at.isBefore(entry)) {
            throw new IllegalArgumentException(
                "Exit time cannot be before entry time"
            );
        }

        Money calculatedFare = Objects.requireNonNull(
            policy.calculate(entry, at),
            "Calculated fare cannot be null"
        );

        if (calculatedFare.isNegative()) {
            throw new IllegalArgumentException("Fare cannot be negative");
        }

        this.exit = at;
        this.fare = calculatedFare;

        return fare;
    }

    public TicketId getId() {
        return id;
    }

    public SpotId getSpotId() {
        return spotId;
    }

    public Instant getEntry() {
        return entry;
    }

    public Instant getExit() {
        return exit;
    }

    public Money getFare() {
        return fare;
    }
}
