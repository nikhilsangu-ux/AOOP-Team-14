
package waypoint.model;

import java.util.Objects;

/**
 * Distinct ID types so they can never be swapped at a call site.
 */
public record TicketId(String value) {

    public TicketId {
        Objects.requireNonNull(value, "TicketId cannot be null");

        value = value.trim();

        if (value.isEmpty()) {
            throw new IllegalArgumentException("TicketId cannot be blank");
        }
    }
}

record SpotId(String value) {

    public SpotId {
        Objects.requireNonNull(value, "SpotId cannot be null");

        value = value.trim();

        if (value.isEmpty()) {
            throw new IllegalArgumentException("SpotId cannot be blank");
        }
    }
}
